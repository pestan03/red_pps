<?php
// Conexión a la base de datos (modifica estos valores según tu configuración)
include './conexion.php';

// Crear conexión
// Establecer el modo de error PDO a excepción
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Verifica si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica si los campos de usuario y contraseña no están vacíos
    if (!empty($_POST['user']) && !empty($_POST['pass'])) {
        $user = $_POST['user'];
        $pass = $_POST['pass'];

        // Consulta para obtener el hash de la contraseña desde la base de datos
        $sql = "SELECT id, user, password FROM usuarios WHERE user = :user";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':user', $user);
        $stmt->execute();

        if ($stmt->rowCount() == 1) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $stored_password = $row['password'];

            // Calcula el hash SHA-256 de la contraseña ingresada
            $hashed_password = hash('sha256', $pass);

            // Verifica si los hashes coinciden
            if ($hashed_password === $stored_password) {
                // Iniciar sesión y redirigir al usuario a una página de bienvenida
                session_start();
                setcookie("cookie_session", $row['id'], time() + 3600, "/");             
                header("Location: ../index.php");
            } else {
                // Si las credenciales son incorrectas, muestra un mensaje de error
                echo "Nombre de usuario o contraseña incorrectos.";
            }
        } else {
            // Si el usuario no existe en la base de datos, muestra un mensaje de error
            echo "Nombre de usuario o contraseña incorrectos.";
        }
    } else {
        // Si los campos están vacíos, muestra un mensaje de error
        echo "Por favor, complete todos los campos.";
    }
}



// Si no hay sesión iniciada, mostrar el formulario de inicio de sesión
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
</head>

<body>
    <h2>Iniciar Sesión</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="username">Nombre de Usuario:</label>
        <input type="text" name="username" id="username" required>
        <br>
        <label for="password">Contraseña:</label>
        <input type="password" name="password" id="password" required>
        <br>
        <button type="submit">Iniciar Sesión</button>
    </form>
    <script src="index.js"></script>
</body>

</html>