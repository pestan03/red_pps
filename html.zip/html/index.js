document.addEventListener("DOMContentLoaded", function () {
    const overlayTrigger = document.querySelector('.overlay-trigger');
    const overlay = document.querySelector('.overlay');

    overlayTrigger.addEventListener('click', function () {
        overlay.classList.toggle('active');
    });

    overlay.querySelector('.close-button').addEventListener('click', function () {
        overlay.classList.remove('active');
    });
});


function borrarCookie() {
    // Establecer la fecha de expiración en el pasado
    document.cookie = 'cookie_session=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    // Recargar la página para reflejar los cambios
    location.reload();
}
window.addEventListener('keydown', function (event) {
    // Verificar si se presionó la tecla R y si al mismo tiempo se presionó Ctrl (o Cmd en Mac)
    if ((event.key === 'r' || event.key === 'R') && (event.ctrlKey || event.metaKey)) {
        // Ejecutar la función para borrar la cookie
        borrarCookie();
    }
});
// Espera a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function () {
    // Selecciona todos los elementos con la clase 'mensaje-texto'
    const elementosMensajeTexto = document.querySelectorAll('.mensaje .mensaje-texto');

    // Agrega un controlador de eventos clic a cada elemento con la clase 'mensaje-texto'
    elementosMensajeTexto.forEach(elemento => {
        elemento.addEventListener('click', function () {
            // Obtiene el valor de 'data-message-id' del elemento padre
            const noticiaId = this.parentElement.getAttribute('data-noticia-id');

            // Guarda el valor en sessionStorage
            sessionStorage.setItem('noticiaId', noticiaId);

            // Redirige a la página deseada
            // Aquí puedes cambiar 'vermensaje.php' por la página a la que deseas redirigir
            window.location.href = '/vernoticia.php?noticiaId=' + noticiaId;
        });
    });
});
document.addEventListener('DOMContentLoaded', function () {
    // Selecciona todos los elementos con la clase 'mensaje-texto'
    const elementosMensajeTexto = document.querySelectorAll('.mensaje .nombre-usuario');

    // Agrega un controlador de eventos clic a cada elemento con la clase 'mensaje-texto'
    elementosMensajeTexto.forEach(elemento => {
        elemento.addEventListener('click', function () {
            // Obtiene el valor de 'data-message-id' del elemento padre
            const messageId = this.parentElement.getAttribute('data-noticia-id');

            // Guarda el valor en sessionStorage
            sessionStorage.setItem('noticiaId', noticiaId);

            // Redirige a la página deseada
            // Aquí puedes cambiar 'vermensaje.php' por la página a la que deseas redirigir
            window.location.href = '/perfil.php?noticiaId=' + noticiaId;
        });
    });
});

// MUESTRA DESPLEGABLE DE PERFIL Y LOGOUT
function showDropdown() {
    var dropdown = document.getElementById("myDropdown");
    dropdown.classList.add("show");
}

function hideDropdown() {
    var dropdown = document.getElementById("myDropdown");
    dropdown.classList.remove("show");
}

document.querySelector('.dropbtn').addEventListener('mouseenter', showDropdown);
document.querySelector('.dropbtn').addEventListener('mouseleave', hideDropdown);

window.onclick = function (event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        for (var i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}


//FUNCION DE VALIDACION DE PASSWORD
function validarPassword() {
    const password = document.getElementById("pass").value;
    const passError = document.getElementById("passError");
    const submitBtn = document.getElementById("submitBtn");
    
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    
    if (password.match(regex)) {
        passError.textContent = "";
        submitBtn.disabled = false;
    } else {
        passError.textContent = "La contraseña debe tener al menos 8 caracteres, una mayúscula, una minúscula, un número y un carácter especial.";
        submitBtn.disabled = true;
    }
}

document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("input-imagen").addEventListener("change", function() {
        var file = this.files[0];
        var allowedExtensions = /(\.jpg|\.png)$/i;
        if (!allowedExtensions.exec(file.name)) {
            alert('Por favor, selecciona un archivo con extensión .jpg o .png');
            this.value = '';
            return false;
        }
        document.getElementById("btn-guardar").style.display = "block";
    });
});


// Obtén la referencia a la imagen
function selectImage() {
    const fileInput = document.getElementById('imagen');
    fileInput.click();
}

// OBJETO MOVIBLE
// Obtener el objeto movible
var objetoMovible = document.getElementById('objetoMovible');

// Función para mostrar los iconos al hacer clic en la foto principal
var fotoPrincipal = document.getElementById('imagenPrincipal');
fotoPrincipal.addEventListener('click', function() {
  var iconos = document.getElementsByClassName('icono');
  for (var i = 0; i < iconos.length; i++) {
    iconos[i].style.display = 'block';
  }
});

// Ocultar los iconos cuando se hace clic en cualquier parte de la pantalla
document.addEventListener('click', function(e) {
  if (e.target !== fotoPrincipal) {
    var iconos = document.getElementsByClassName('icono');
    for (var i = 0; i < iconos.length; i++) {
      iconos[i].style.display = 'none';
    }
  }
});
