<?php
// Verificar si la cookie de sesión existe
if (isset($_COOKIE['cookie_session'])) {
    // Obtener el message_id del comentario donde se quiere agregar el nuevo comentario

    // Obtener el contenido del comentario desde el formulario
    if (isset($_POST['comentario'])) {
        $content = $_POST['comentario'];
        $noticia_id = $_POST['idnoticia'];
        // Obtener el user_id del usuario que está comentando desde la cookie de sesión
        $user_id = $_COOKIE['cookie_session'];

        // Conectar a la base de datos
        $servername = "db";
        $username = "root";
        $password = "root_password";
        $database = "red";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Insertar el nuevo comentario en la base de datos
        $sql = "INSERT INTO comentarios (id_noticia, user_id, contenido, datesent) VALUES (:id_noticia, :user_id, :content, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_noticia', $noticia_id);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':content', $content);
        $stmt->execute();

        // Redirigir de vuelta a la página anterior después de agregar el comentario
        header("Location: {$_SERVER['HTTP_REFERER']}");
        exit();
    } else {
        echo "Error: El contenido del comentario no se ha recibido.";
    }
} else {
    echo "Error: No se ha iniciado sesión.";
}
?>
<script src="index.js"></script>