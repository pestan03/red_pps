<?php
    $servername = "db";
    $username = "root";
    $password = "root_password"; // Sin contraseña
    $database = "red";
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
?>